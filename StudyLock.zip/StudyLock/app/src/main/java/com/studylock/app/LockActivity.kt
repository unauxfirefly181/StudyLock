package com.studylock.app

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LockActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var countdownText: TextView
    private lateinit var unlockLayout: View
    private lateinit var codeDisplay: TextView
    private lateinit var codeInput: EditText

    private val tickRunnable = object : Runnable {
        override fun run() {
            updateCountdown()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
        )
        setContentView(R.layout.activity_lock)
        prefs = getSharedPreferences(MainActivity.PREFS_NAME, MODE_PRIVATE)

        countdownText = findViewById(R.id.countdownText)
        unlockLayout = findViewById(R.id.unlockLayout)
        codeDisplay = findViewById(R.id.codeDisplay)
        codeInput = findViewById(R.id.codeInput)

        findViewById<Button>(R.id.unlockButton).setOnClickListener {
            val entered = codeInput.text.toString()
            val real = prefs.getString(MainActivity.KEY_CODE, null)
            if (entered == real) {
                endSession()
            } else {
                Toast.makeText(this, "Wrong code", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (!isInLockTaskMode()) {
            try {
                startLockTask()
            } catch (e: Exception) {
                // Some OEMs restrict this. The countdown/notification still track the session.
            }
        }
        handler.post(tickRunnable)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tickRunnable)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val endTime = prefs.getLong(MainActivity.KEY_END_TIME, 0L)
        if (System.currentTimeMillis() >= endTime) {
            super.onBackPressed()
        }
        // Otherwise: swallow the back press, session is still active.
    }

    private fun isInLockTaskMode(): Boolean {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        return am.lockTaskModeState != ActivityManager.LOCK_TASK_MODE_NONE
    }

    private fun updateCountdown() {
        val endTime = prefs.getLong(MainActivity.KEY_END_TIME, 0L)
        val remaining = endTime - System.currentTimeMillis()
        if (remaining <= 0) {
            showUnlockScreen()
        } else {
            val totalSeconds = remaining / 1000
            val h = totalSeconds / 3600
            val m = (totalSeconds % 3600) / 60
            val s = totalSeconds % 60
            countdownText.text = String.format("%02d:%02d:%02d", h, m, s)
        }
    }

    private fun showUnlockScreen() {
        countdownText.text = "00:00:00"
        unlockLayout.visibility = View.VISIBLE
        val code = prefs.getString(MainActivity.KEY_CODE, "------")
        codeDisplay.text = "Time's up! Your code: $code"
    }

    private fun endSession() {
        if (isInLockTaskMode()) {
            try {
                stopLockTask()
            } catch (e: Exception) {
            }
        }
        prefs.edit().clear().apply()
        stopService(Intent(this, LockService::class.java))
        finish()
    }
}

package com.studylock.app

import android.Manifest
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)

        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1
                )
            }
        }

        val minutesInput = findViewById<EditText>(R.id.minutesInput)
        minutesInput.setText("120")

        findViewById<Button>(R.id.startButton).setOnClickListener {
            val minutes = minutesInput.text.toString().toIntOrNull()
            if (minutes == null || minutes <= 0) {
                Toast.makeText(this, "Enter a valid number of minutes", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            startLockSession(minutes)
        }

        // If a session is already running (app relaunched mid-session), jump straight back in.
        if (prefs.getLong(KEY_END_TIME, 0L) > System.currentTimeMillis()) {
            startActivity(Intent(this, LockActivity::class.java))
        }
    }

    private fun startLockSession(minutes: Int) {
        val code = Random.nextInt(100000, 999999).toString()
        val durationMs = minutes * 60_000L
        val endTime = System.currentTimeMillis() + durationMs

        prefs.edit()
            .putString(KEY_CODE, code)
            .putLong(KEY_END_TIME, endTime)
            .putLong(KEY_DURATION, durationMs)
            .apply()

        startForegroundService(Intent(this, LockService::class.java))
        startActivity(Intent(this, LockActivity::class.java))
    }

    companion object {
        const val PREFS_NAME = "study_lock_prefs"
        const val KEY_CODE = "unlock_code"
        const val KEY_END_TIME = "end_time"
        const val KEY_DURATION = "duration_ms"
    }
}
